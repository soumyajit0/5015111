package dependencies;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
