package dependencies;

public interface Command {
    void execute();
}
