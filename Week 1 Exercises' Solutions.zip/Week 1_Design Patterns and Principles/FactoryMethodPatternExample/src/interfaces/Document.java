package interfaces;

public interface Document {
  public void create();
}
