package dependencies;

public interface PaymentProcessor {
    void processPayment(double amount);
}
