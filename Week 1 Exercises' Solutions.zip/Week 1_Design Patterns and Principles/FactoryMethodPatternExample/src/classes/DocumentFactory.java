package classes;

import interfaces.Document;

public abstract class DocumentFactory {
  public abstract Document createDocument();
}
