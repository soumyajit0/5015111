package dependencies;

public interface Image {
    void display();
}
