package dependencies;

public interface PaymentStrategy {
    void pay(int amount);
}
