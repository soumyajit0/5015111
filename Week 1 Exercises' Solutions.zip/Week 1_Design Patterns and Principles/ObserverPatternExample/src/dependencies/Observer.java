package dependencies;

public interface Observer {
    void update(String stockName, double stockPrice);
}
